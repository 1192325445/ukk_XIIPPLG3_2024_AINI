<?php

phpinfo();

?>
echo "<script>
	alert ('Data berhasil disimpan!');
	location.href='../admin/album.php';
	</script>";